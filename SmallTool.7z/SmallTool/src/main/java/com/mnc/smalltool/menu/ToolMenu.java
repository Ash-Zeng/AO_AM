package com.mnc.smalltool.menu;

import com.mnc.smalltool.config.Config;
import com.mnc.smalltool.function.impl.BoFunctionImpl;
import com.mnc.smalltool.function.impl.FunctionStrategy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.util.Properties;

/**
 * tool function menu
 */
@Slf4j
public class ToolMenu {
    /**
     * the function entrance
     * @param args
     */
    public void executeToolFunction(String[] args) {
        // tips message
        StringBuffer sb = new StringBuffer();

        // no args param
        if (args.length == 0) {
            sb.append("  小智为您提供以下功能:\n")
               .append("    1. 对比BO文件\n")
               .append("    2. 测试一下\n")
               .append("\n")
               .append("  功能启动命令[command function]: java -jar SmallTool-0.0.1.jar 1");

            System.out.println(sb);
            return;
        }

        Config config = getApplicationYamlInfo();
        FunctionStrategy functionStrategy = new FunctionStrategy();

        switch (args[0]) {
            case "1":
                functionStrategy.setToolFunction(new BoFunctionImpl());
                break;
            case "2":

                break;
            default:
                sb.append("  小智还在学习中，暂不支持此功能，回炉重造去...");
                System.out.println(sb);
        }

        // check
        String checkMsg = functionStrategy.checkFunctionParam(config);

        if (StringUtils.isNoneEmpty(checkMsg)) {
            System.out.println(checkMsg);
            return;
        }

        // execute
        functionStrategy.executeFunction();

        return;
    }

    /**
     * read yaml config value
     * @return
     */
    private Config getApplicationYamlInfo() {
        Config config = new Config();
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        String outYmlFilePath = System.getProperty("user.dir") + "\\application.yml";
        File outYmlFile = new File(outYmlFilePath);

        try {
            if (outYmlFile.exists()) {
                yaml.setResources(new FileSystemResource(outYmlFilePath));
            } else {
                yaml.setResources(new ClassPathResource("application.yml"));
            }

            Properties properties = yaml.getObject();
            PropertyDescriptor[] pds = Introspector.getBeanInfo(Config.class, Object.class).getPropertyDescriptors();
            for (PropertyDescriptor pd : pds) {
                String value = (String) properties.get("function." + pd.getName());
                pd.getWriteMethod().invoke(config, value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return config;
    }
}
