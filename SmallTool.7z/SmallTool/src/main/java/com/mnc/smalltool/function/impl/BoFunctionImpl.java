package com.mnc.smalltool.function.impl;

import com.mnc.smalltool.config.Config;
import com.mnc.smalltool.function.ToolFunction;
import org.springframework.stereotype.Component;

@Component
public class BoFunctionImpl implements ToolFunction {

    /**
     * check param
     * @return
     */
    @Override
    public String checkFunctionParam(Config config) {
        System.out.println("check function 1");
        System.out.println("file path is: " + config.getFilePath());
        return null;
    }

    /**
     * execute function
     */
    @Override
    public void executeFunction() {
        System.out.println("execute function 1");
    }
}
