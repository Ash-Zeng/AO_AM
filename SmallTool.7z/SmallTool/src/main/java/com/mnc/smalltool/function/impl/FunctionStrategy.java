package com.mnc.smalltool.function.impl;

import com.mnc.smalltool.config.Config;
import com.mnc.smalltool.function.ToolFunction;

public class FunctionStrategy {
    private ToolFunction toolFunction;

    public void setToolFunction(ToolFunction toolFunction) {
        this.toolFunction = toolFunction;
    }

    public String checkFunctionParam(Config config) {
        return toolFunction.checkFunctionParam(config);
    }

    public void executeFunction() {
        toolFunction.executeFunction();
    }
}
