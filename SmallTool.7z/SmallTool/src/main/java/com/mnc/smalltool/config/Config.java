package com.mnc.smalltool.config;

import lombok.Data;

@Data
public class Config {
    // file root path
    private String filePath;
}
