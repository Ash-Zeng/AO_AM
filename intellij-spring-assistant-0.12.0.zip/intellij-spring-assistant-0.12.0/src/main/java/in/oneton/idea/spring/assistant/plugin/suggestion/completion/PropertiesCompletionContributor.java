package in.oneton.idea.spring.assistant.plugin.suggestion.completion;

public class PropertiesCompletionContributor {
  //    extends CompletionContributor {

  //  public PropertiesCompletionContributor() {
  //    extend(CompletionType.BASIC,
  //        PlatformPatterns.psiElement().withLanguage(PropertiesLanguage.INSTANCE),
  //        new PropertiesCompletionProvider());
  //  }

}
