package in.oneton.idea.spring.assistant.plugin.suggestion.metadata.json;

public enum SpringConfigurationMetadataDeprecationLevel {
  warning, error
}
