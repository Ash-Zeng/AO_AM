package in.oneton.idea.spring.assistant.plugin.suggestion.metadata.json;

public interface GsonPostProcessable {
  void doOnGsonDeserialization();
}
