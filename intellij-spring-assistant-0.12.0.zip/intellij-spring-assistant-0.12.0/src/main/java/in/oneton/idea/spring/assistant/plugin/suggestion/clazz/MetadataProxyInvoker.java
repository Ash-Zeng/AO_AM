package in.oneton.idea.spring.assistant.plugin.suggestion.clazz;

public interface MetadataProxyInvoker {
  void invoke(MetadataProxy delegate);
}
