package in.oneton.idea.spring.assistant.plugin.suggestion.metadata.json;

public enum SpringConfigurationMetadataKnownValueProvider {
  any, class_reference, handle_as, logger_name, spring_bean_reference, spring_profile_name
}
