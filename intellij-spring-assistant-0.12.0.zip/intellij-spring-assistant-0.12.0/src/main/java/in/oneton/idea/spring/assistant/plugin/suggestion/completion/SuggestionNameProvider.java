package in.oneton.idea.spring.assistant.plugin.suggestion.completion;

public interface SuggestionNameProvider {
}
