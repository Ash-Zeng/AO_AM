package model;

public enum TopLevelEnum {
  enum1, enum2, enum3
}
