package com.acme.model;

/**
 * Enum documentation (from within)
 */
public enum DynamicEnum {
  /**
   * Val1 documentation
   */
  val1,
  /**
   * Val2 documentation
   */
  VAL2
}
