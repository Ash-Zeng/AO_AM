package com.acme.model;

import lombok.Data;

@Data
public class ChildNode {
  private String childStringProperty;
}
