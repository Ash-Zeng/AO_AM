package com.example.singlemodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingleModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SingleModuleApplication.class, args);
	}
}
