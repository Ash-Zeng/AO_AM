# idea-spring-tools
Spring support for IntelliJ CE based on the STS4 Language Server

### Distribution
Currently the plugin distribution is upload to https://dl.bintray.com/gayanper/idea-spring-tools/