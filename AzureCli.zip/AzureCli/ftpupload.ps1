$appdirectory="D:\AzureCli\test" 
Set-Location $appdirectory
$username = "curepoc\`$curepoc"
$password = "qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz"
$url="ftp://waws-prod-hk1-029.ftp.azurewebsites.windows.net"
$webclient = New-Object -TypeName System.Net.WebClient
$webclient.Credentials = New-Object System.Net.NetworkCredential($username,$password)
$files = Get-ChildItem -Path $appdirectory -Recurse | Where-Object{!($_.PSIsContainer)}
foreach ($file in $files)
{
    $relativepath = (Resolve-Path -Path $file.FullName -Relative).Replace(".\", "").Replace('\', '/')
    $uri = New-Object System.Uri("$url/site/wwwroot/$relativepath")
    "Uploading to " + $uri.AbsoluteUri
    $webclient.UploadFile($uri, $file.FullName)
} 
$webclient.Dispose()