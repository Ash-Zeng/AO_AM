gitlab   http://192.168.1.101:8848
administrator   root  chinasofti
zhouxin         zhouxin013@chinasofti.com   
pengna          pengna@chinasofti.com       
lihuan    lihuan0309
yinjie    yinjie2021
yangsiyuan  yangsiyuan2021
yangziyue   yangziyue2021

cloud
api doc: http://192.168.1.103:8010/doc.html 
spring boot admin  : http://192.168.1.103:7002
nacos: http://192.168.1.103:8848   nacos/nacos
Sentinel  http://192.168.1.103:8858/  sentinel/sentinel

auth/token: 
Header
    Authorization = Basic c2FiZXI6c2FiZXJfc2VjcmV0
Post
    username = admin
    password = 123456
    tenantId = 000000
    grantType = password

rest http
Header
    Micro-Auth  ${token_type} ${access_token}
    Micro-Auth  bearer   xxxx
Post
Get

${token_type} = bearer
${access_token} = eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpc3N1c2VyIiwiYXVkIjoiYXVkaWVuY2UiLCJ0ZW5hbnRfaWQiOiIwMDAwMDAiLCJyb2xlX25hbWUiOiJhZG1pbmlzdHJhdG9yIiwidXNlcl9pZCI6IjExMjM1OTg4MjE3Mzg2NzUyMDEiLCJyb2xlX2lkIjoiMTEyMzU5ODgxNjczODY3NTIwMSIsInVzZXJfbmFtZSI6ImFkbWluIiwib2F1dGhfaWQiOiIiLCJ0b2tlbl90eXBlIjoiYWNjZXNzX3Rva2VuIiwiYWNjb3VudCI6ImFkbWluIiwiY2xpZW50X2lkIjoic2FiZXIiLCJleHAiOjE2MDc5MTQzMzksIm5iZiI6MTYwNzkxMDczOX0.Bo2TgBsIj9-1MDLcmCCC6rBWOFDtDTxqYRpwSv3puQ_jdceSIXWqVeYBMO1f2bND1iHRrDH5zcX5KoPv9eDZEw
主机
192.168.1.101
  sky/3edc  root/zx883408  
192.168.1.103
  root/3edc

  GITHUB
  JIRA
  Jenkins
  SonarQube
  SonarType IQ
  CheckMarx
  Nexus
  AppDyanmics
  G3
  RTC
  
mvn install:install-file -DgroupId=com.oracle -DartifactId=ojdbc8 -Dversion=19.3 -Dpackaging=jar -Dfile=C:\Users\Arvin\Downloads\ojdbc8.jar 

oracle19c zx883408
orcl Zx.883408
ARVIN 883408
https://localhost.navicat.com:5500/em

zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com Goto0085

Arvin
Arvin.883408

Azure Boards      计划工具
Azure Pipelines   CI/CD
Azure Repos       代码托管
Azure Artifacts   包托管
Azure Test Plan   测试管理

NETSDK1138: The target framework 'netcoreapp2.2' is out of support and will not receive security updates in the future. Please refer to https://aka.ms/dotnet-core-support for more information about the support policy.

Azure virtual machine scale set 需要



azure devops token ： ymaayvwuo2evosxnfccbnfcfa4bpvo3p3uckbnjvzwanxohhagwq


Add-Type -AssemblyName System.IO.Compression.FileSystem ; [System.IO.Compression.ZipFile]::ExtractToDirectory("D:\sts-agent-win-x64-2.184.2.zip", "ymaayvwuo2evosxnfccbnfcfa4bpvo3p3uckbnjvzwanxohhagwq")


https://dev.azure.com/{your-organization}

https://dev.azure.com/zengweiwei0295

cd D:\vsts-agent-win-x64-2.184.2\_work\_tool\NuGet

.\nuget.exe install s.zip -OutputDirectory -${System.DefaultWorkingDirectory} -configfile D:\vsts-agent-win-x64-2.184.2\Nuget.Config


Azure CLI
az login -u zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com -p Goto0085
az webapp deployment source config-zip --resource-group zengweiwei --name curepoc --src D:\AzureCli\arvexception.zip

Kudu restapi


get publish profile , username and userPWD
cmd
curl -X POST -u $restdemo:WcaxjAS3apHkedbs3lbqDNjnAjmbgYhkPgEsSyku4QLgtDydaNnmZxNeEGc0 --data-binary @"D:\AzureCli\cli-demo.zip" https://restdemo.scm.azurewebsites.net/api/zipdeploy

react
curl -X DELETE -u $curepoc:qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz https://curepoc.scm.azurewebsites.net/api/vfs/site/wwwroot?recursive=true

curl -X PUT -u $curepoc:qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz --data-binary @"D:\AzureCli\test.zip" https://curepoc.scm.azurewebsites.net/api/zip/site/wwwroot

Azure powershell 
Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force -AllowClobber



https://curepoc.scm.azurewebsites.net/api/zipdeploy/?isAsync=true

$User = "zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "Goto0085" -AsPlainText -Force
$tenant = "9349e29b-779b-4883-a118-b5be4d6dc66a"
$subscription = "7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8"
$Credential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $User,$PWord
Connect-AzAccount -Credential $Credential -Tenant $tenant -Subscription $subscription
Publish-AzWebapp -ResourceGroupName Zengweiwei -Name restdemo -ArchivePath D:\AzureCli\cli-demo.zip


$pair = "$restdemo:WcaxjAS3apHkedbs3lbqDNjnAjmbgYhkPgEsSyku4QLgtDydaNnmZxNeEGc0"
$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
$basicAuthValue = "Basic $encodedCreds"
$Headers = @{
    Authorization = $basicAuthValue
}
$sourceFilePath = "D:\AzureCli\cli-demo.zip" 
Invoke-WebRequest -Uri https://restdemo.azurewebsites.net/api/zipdeploy -Headers $Headers `
    -InFile $sourceFilePath -ContentType "multipart/form-data" -Method Post


$username = "$restdemo"
$password = "WcaxjAS3apHkedbs3lbqDNjnAjmbgYhkPgEsSyku4QLgtDydaNnmZxNeEGc0"
$filePath = "D:\AzureCli\cli-demo.zip"
$apiUrl = "https://restdemo.scm.azurewebsites.net:443/api/zipdeploy"
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username, $password)))
$userAgent = "powershell/1.0"
Invoke-RestMethod -Uri $apiUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -UserAgent $userAgent -Method POST -InFile $filePath -ContentType "multipart/form-data"

-------------------------------------------------------------------------------------------------------------------------
$username = "`$curepoc"
$password = "qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz"
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username, $password)))
$userAgent = "powershell/1.0"
$apiUrl = "https://arvapp.scm.azurewebsites.net:443/api/zipdeploy/"
$filePath = "D:\AzureCli\arvapp1.zip" 
Invoke-RestMethod -Uri $apiUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -UserAgent $userAgent -Method PUT -InFile $filePath -ContentType "multipart/form-data"



https://docs.microsoft.com/en-us/azure/app-service/deploy-staging-slots
az login -u zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com -p Goto0085
az webapp deployment slot delete --name arvapp --resource-group zengweiwei --slot staging
az webapp deployment slot create --name arvapp --resource-group zengweiwei --slot staging
az webapp deployment slot auto-swap --name arvapp --resource-group zengweiwei --slot staging
az webapp deployment slot swap  --resource-group zengweiwei --name curepoc --slot staging --target-slot production
az webapp deployment source config-zip --resource-group zengweiwei --name arvapp --slot staging --src D:\AzureCli\arvapp1.zip
az webapp traffic-routing show --name arvapp --resource-group zengweiwei
az webapp traffic-routing set --distribution staging=20 --name arvapp --resource-group zengweiwei

az monitor metrics alert show --name CURE-heatleh-check-alert --resource-group zengweiwei
az monitor alert list-incidents --resource-group Zengweiwei --rule-name CURE-heatleh-check-alert

az monitor alert show --name curepoc-stage-alert --resource-group Zengweiwei
az monitor metrics alert show --ids /subscriptions/7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8/resourceGroups/Zengweiwei/providers/microsoft.insights/metricalerts/curepoc-stage-alert

az monitor alert show-incident --ids /subscriptions/7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8/resourceGroups/Zengweiwei/providers/microsoft.insights/metricalerts/curepoc-stage-alert

https://management.azure.com/7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8/providers/Microsoft.AlertsManagement/alerts/22a58f2-4606-4ae1-b6eb-1b3005c5e7c0?api-version=2019-03-01

 az monitor metrics list-definitions --resource

az login -u zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com -p Goto0085
$json = az monitor metrics list --resource /subscriptions/7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8/resourceGroups/zengweiwei/providers/Microsoft.Web/sites/curepoc/slots/staging --metric HealthCheckStatus --interval PT24H
$jsonObj = $whatStatusJsonContent | ConvertFrom-Json
$http5xxCount = $json.timeseries.data.count
if( $http5xxCount -eq 0 ){ Write-Output "http5xxCount == 0" } else { Write-Output "http5xxCount != 0" }

设置代理
netsh winhttp set proxy 127.0.0.1:1080
取消代理
netsh winhttp reset proxy
查看代理
netsh winhttp show proxy


traces
| where message contains "index" 
| order by timestamp desc 
| count 


ftp://waws-prod-hk1-029.ftp.azurewebsites.windows.net/site/wwwroot
curepoc\$curepoc
qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz


Add-Type -Path "WinSCPnet.dll"
#$sessionOptions = New-Object WinSCP.SessionOptions

$sessionOptions1 = New-Object WinSCP.SessionOptions -Property @{
    Protocol = [WinSCP.Protocol]::Ftp
    HostName = "waws-prod-hk1-029.ftp.azurewebsites.windows.net"
    UserName = "curepoc\$curepoc"
    Password = "qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz"
}

#$sessionOptions.ParseUrl("ftp://waws-prod-hk1-029.ftp.azurewebsites.windows.net/site/wwwroot")

$session = New-Object WinSCP.Session
$session.Open($sessionOptions)

$session.PutFiles("D:\AzureCli\test\*", "/site/wwwroot/test/").Check()

$session.Dispose()



$source1 = "D:\AzureCli\test\test.txt"
$destination = "ftp://waws-prod-hk1-029.ftp.azurewebsites.windows.net:21/site/wwwroot"
$username = "curepoc\$curepoc"
$password = "qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz"
# $cred = Get-Credential
$wc = New-Object System.Net.WebClient
$wc.Credentials = New-Object System.Net.NetworkCredential($username, $password)

$files = get-childitem $source -recurse -force
foreach ($file in $files)
{
    $localfile = $file.fullname
}
$wc.UploadFile($destination, $source1)
$wc.Dispose()



$appdirectory="<Replace with your app directory>"
$webappname="mywebapp$(Get-Random)"
$location="West Europe"

# Create a resource group.
New-AzResourceGroup -Name myResourceGroup -Location $location

# Create an App Service plan in `Free` tier.
New-AzAppServicePlan -Name $webappname -Location $location `
-ResourceGroupName myResourceGroup -Tier Free

# Create a web app.
New-AzWebApp -Name $webappname -Location $location -AppServicePlan $webappname `
-ResourceGroupName myResourceGroup

# Get publishing profile for the web app
$xml = [xml](Get-AzWebAppPublishingProfile -Name $webappname `
-ResourceGroupName myResourceGroup `
-OutputFile null)

# Extract connection information from publishing profile
$username = $xml.SelectNodes("//publishProfile[@publishMethod=`"FTP`"]/@userName").value
$password = $xml.SelectNodes("//publishProfile[@publishMethod=`"FTP`"]/@userPWD").value
$url = $xml.SelectNodes("//publishProfile[@publishMethod=`"FTP`"]/@publishUrl").value

# Upload files recursively
$appdirectory="D:\AzureCli\test" 
Set-Location $appdirectory
$username = "curepoc\`$curepoc"
$password = "qjciEr5uTdmY2trS1oLszPv7m40fQDAvXN7qRcKvir9MhcQJedSEJTWuE7oz"
$url="ftp://waws-prod-hk1-029.ftp.azurewebsites.windows.net"
$webclient = New-Object -TypeName System.Net.WebClient
$webclient.Credentials = New-Object System.Net.NetworkCredential($username,$password)
$files = Get-ChildItem -Path $appdirectory -Recurse | Where-Object{!($_.PSIsContainer)}
foreach ($file in $files)
{
    $relativepath = (Resolve-Path -Path $file.FullName -Relative).Replace(".\", "").Replace('\', '/')
    $uri = New-Object System.Uri("$url/site/wwwroot/$relativepath")
    "Uploading to " + $uri.AbsoluteUri
    $webclient.UploadFile($uri, $file.FullName)
} 
$webclient.Dispose()