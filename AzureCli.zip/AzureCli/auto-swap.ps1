az login -u zengweiwei@xiejunhuichinasoftinc.onmicrosoft.com -p Goto0085
$json = az monitor metrics list --resource /subscriptions/7d5b3896-0b6b-4ace-962f-0e73ffd1c3b8/resourceGroups/zengweiwei/providers/Microsoft.Web/sites/curepoc/slots/staging --metric HealthCheckStatus --interval PT24H
$jsonObj = $json | ConvertFrom-Json
$http5xxCount = $json.timeseries.data.count
if( $http5xxCount -eq 0 ){ az webapp deployment slot swap  --resource-group zengweiwei --name curepoc --slot staging --target-slot production } else { Write-Output "http5xxCount != 0" }
return